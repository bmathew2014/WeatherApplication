package com.example.dbm0204.weatherapplication;

public enum CallOrigin {
    HOME
}
