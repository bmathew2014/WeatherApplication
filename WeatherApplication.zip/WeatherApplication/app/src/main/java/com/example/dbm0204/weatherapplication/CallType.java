package com.example.dbm0204.weatherapplication;

public enum CallType {
    WEATHER_REPORT_FOR_CITY_NAME
}